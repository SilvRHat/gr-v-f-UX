// Gr@v:f/UX
// Gavin:Zimmerman

// Noise Functions
#ifndef NOISE_H
#define NOISE_H


// DEPENDENCIES
#include "linmath.h"


// MEMBERS
float snoise3(vec3 pos);


#endif